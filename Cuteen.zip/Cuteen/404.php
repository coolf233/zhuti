<?php
/**
 * Author: Veen Zhao
 * CreateTime: 2020/11/7 13:53
 */
echo '404';
<?php
/**
 * Author: Veen Zhao
 * CreateTime: 2020/9/8 15:30
 * 全局配置文件
 */
return array(
    'version' => '4.0',
    'theme'=>'Cuteen',
);